package com.example.myseries;

public class MyData {
    static String[] nameArray = {
            "Avinoam Lesri",
            "Meir Sebag",
            "Gedalia",
            "Dov Lazer Brown",
            "Deborah Brown",
            "Rabbi Ashi Spitzer",
            "Shira",
            "Rabbi Eliyahu Lesri",
            "Rabbi Yosef Bloch",
            "Shlomi Zaks",
            "Ehud Stern"};
    static String[] versionArray = {
            " The son of a member of the Knesset."
            , "Yeshiva student of Mizrahi origin and with learning difficulties.",
            "An ultra-Orthodox scholar who is strict about lightness and severity.",
            "The son of a wealthy American family.",
            "Dov Lazer's opinionated twin sister.",
            "An ultra-orthodox rabbi who is appointed to act as an overseer at a yeshiva.",
            "Architecture student, secular who works as a waitress.",
            "Avinoam's father, MK and member of the finance committee on behalf of Shas."
            , " The head of the Netivot Avraham yeshiva.",
            "A renowned matchmaker who runs a prestigious matchmakin agency.",
            "National religious police investigator."};

    static Integer[] drawableArray = {R.drawable.danielg, R.drawable.israela, R.drawable.oril,
            R.drawable.omerp, R.drawable.mayav, R.drawable.rotemk, R.drawable.shiran,
            R.drawable.golana, R.drawable.dovn, R.drawable.guria,R.drawable.zohars};

    static Integer[] id_ = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10};
}
